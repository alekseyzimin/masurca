#ifndef _MEM_MANAGER
#define _MEM_MANAGER
extern MEM_MANAGER *createMem_manager(int num_items,size_t unit_size);
extern void *getItem(MEM_MANAGER *mem_Manager);
extern void returnItem(MEM_MANAGER *mem_Manager,void *);
extern void freeMem_manager(MEM_MANAGER *mem_Manager);
#endif
